Usage
-----

import abssmt
