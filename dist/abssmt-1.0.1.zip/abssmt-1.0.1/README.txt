abssmt
======

Brief Description
-----------------

This is a introductory level project that teaches RubyLearning's "An Introduction to Python" course students on how to uplaod their modules to Python Package Index.

Usage
-----

import abssmt

print(abssmt.abssmt(-20))

