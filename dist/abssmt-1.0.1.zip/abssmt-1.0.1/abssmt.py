""" A function that returns the
    absolute value of a number"""
def abssmt(x):
    if x < 0:
        return -x
    elif x >= 0:
        return x 
